/**
 * Created by divya on 11/3/2015.
 */
'use strict';

var sample = angular.module('sample', ['ngRoute', 'ui.bootstrap']);

/*function MyCtrl($scope) {



    $scope.setSelected = function() {

        alert("alert");
    };

}*/



